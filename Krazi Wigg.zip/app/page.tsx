export default function Home(){
return(<main style={{textAlign:'center',padding:50}}>
<h1>KraziWigg</h1><a href="/feed">Enter</a></main>);
}